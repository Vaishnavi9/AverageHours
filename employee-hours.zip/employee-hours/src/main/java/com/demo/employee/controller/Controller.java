package com.demo.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.employee.models.Employee;
import com.demo.employee.repository.EmployeeRepository;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class Controller {
	
	@Autowired
    EmployeeRepository employeeRepository;

	
	@RequestMapping("/trial")
	public Employee employee() {
		
		return new Employee();
	}
	
	@RequestMapping("/")
	public String index(){
		return "Welcome to spring boot";
		}
	@GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        /*Sort sortByCreatedAtDesc = new Sort(Sort.Direction.DESC, "createdAt");*/
        return employeeRepository.findAll();
    }
	
	

}
