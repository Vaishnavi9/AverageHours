package com.demo.employee.models;

import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
	

	@Document(collection="odcHours")
	public class Employee {
//	    @Id
//	    private String id;
//
//	    @NotBlank
//	    private Integer eId;

	    

	    private String name;
	    private String month;
	    private Double totalHours;
	    private Double averageOdcHoursinMins;
	    private Double averageOdcHoursinHrs;
	    private String role;
	    private String team;

	    /*public Employee(String string) {
	        super();
	    }

	    public Employee(String string,String role) {
	        this.name=null;
	    }
*/
	    
		@Override
	    public String toString() {
	        return String.format(
	                "Employee[month=%s, Name='%s', Role='%s']",
	               month , name, role);
	    }

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getMonth() {
			return month;
		}

		public void setMonth(String month) {
			this.month = month;
		}

		public Double getTotalHours() {
			return totalHours;
		}

		public void setTotalHours(Double totalHours) {
			this.totalHours = totalHours;
		}

		public Double getAverageOdcHoursinMins() {
			return averageOdcHoursinMins;
		}

		public void setAverageOdcHoursinMins(Double averageOdcHoursinMins) {
			this.averageOdcHoursinMins = averageOdcHoursinMins;
		}

		public Double getAverageOdcHoursinHrs() {
			return averageOdcHoursinHrs;
		}

		public void setAverageOdcHoursinHrs(Double averageOdcHoursinHrs) {
			this.averageOdcHoursinHrs = averageOdcHoursinHrs;
		}

		public String getRole() {
			return role;
		}

		public void setRole(String role) {
			this.role = role;
		}

		public String getTeam() {
			return team;
		}

		public void setTeam(String team) {
			this.team = team;
		}
	}


