package com.demo.employee.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.demo.employee.models.Employee;

//@Repository
public interface EmployeeRepository extends MongoRepository<Employee,String>  {
	
	public List<Employee> findAll();
}
